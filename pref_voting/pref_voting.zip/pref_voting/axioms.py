from pref_voting.dominance_axioms import *
from pref_voting.variable_voter_axioms import *
